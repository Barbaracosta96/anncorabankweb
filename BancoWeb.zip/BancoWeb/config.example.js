const config = {
	PROJECT: 'anncora',
	PRODUCTION: false,
};

module.exports = config;
