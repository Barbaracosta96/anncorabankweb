/** @type {import('next').NextConfig} */
let config;
try {
	config = require('./config.js');
} catch (error) {
	config = {};
}
const nextConfig = {
	reactStrictMode: true,
	env: {
		// eslint-disable-next-line no-undef
		PROJECT: config?.PROJECT || 'bithive',
		PRODUCTION: config?.PRODUCTION || false,
	},
};

module.exports = nextConfig;
